﻿namespace Scheduling_App.Properties
{
    internal sealed partial class Settings
    {
        public Settings()
        {
        }
    }
}
